#include "Server.h"

#include <iostream>

POCO_SERVER_MAIN(Server)
