#include <cstdio>

int main() {
	printf("hello from ConsoleApp")
	return 0;
}