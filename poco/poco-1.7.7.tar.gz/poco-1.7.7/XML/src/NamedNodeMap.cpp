//
// NamedNodeMap.cpp
//
// $Id: //poco/1.4/XML/src/NamedNodeMap.cpp#1 $
//
// Library: XML
// Package: DOM
// Module:  DOM
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/DOM/NamedNodeMap.h"


namespace Poco {
namespace XML {


NamedNodeMap::~NamedNodeMap()
{
}


} } // namespace Poco::XML
