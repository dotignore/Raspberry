//
// LexicalHandler.cpp
//
// $Id: //poco/1.4/XML/src/LexicalHandler.cpp#1 $
//
// Library: XML
// Package: SAX
// Module:  SAX
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/SAX/LexicalHandler.h"


namespace Poco {
namespace XML {


LexicalHandler::~LexicalHandler()
{
}


} } // namespace Poco::XML
