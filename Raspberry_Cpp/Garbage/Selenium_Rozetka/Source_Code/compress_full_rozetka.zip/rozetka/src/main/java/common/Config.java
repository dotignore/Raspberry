package common;

public class Config {
    /**
     * Specify the browser to test:
     * chrome_mac, chrome_windows, mozzila_mac
     **/
    public static String BROWSER_NAME = "chrome_mac";

}
