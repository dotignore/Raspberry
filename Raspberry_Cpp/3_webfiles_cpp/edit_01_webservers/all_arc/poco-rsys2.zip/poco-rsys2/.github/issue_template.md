#### Expected behavior

#### Actual behavior

#### Steps to reproduce the problem
(please make this a [SSCCE](http://www.sscce.org/), if applicable and reasonable)

#### POCO version

#### Compiler and version

#### Operating system and version

#### Other relevant information
