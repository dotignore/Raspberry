//
// Unicode_WIN32.h
//
// Forward header for the Unicode_WIN32 class.
//
// Copyright (c) 2008, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/SQL/ODBC/Unicode_WIN32.h"
