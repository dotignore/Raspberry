#!/bin/bash

echo "Deploying the Application..."
