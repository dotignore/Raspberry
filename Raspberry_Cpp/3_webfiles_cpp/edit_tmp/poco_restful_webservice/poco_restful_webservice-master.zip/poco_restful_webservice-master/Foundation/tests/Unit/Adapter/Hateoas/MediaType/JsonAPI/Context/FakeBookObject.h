#ifndef UnitTests_Hateoas_MediaType_Context_FakeBookObject_INCLUDED
#define UnitTests_Hateoas_MediaType_Context_FakeBookObject_INCLUDED

#include <string>

namespace UnitTests {
namespace Hateoas {
namespace Context {


    struct FakeBookObject
    {
        std::string identity;
        std::string title;

    };


} } }

#endif
