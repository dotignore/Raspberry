#include "Adapter/Hateoas/MediaType/JsonAPI/JsonAPIAbstractRelatedResourceBuilder.h"

namespace Hateoas {


    std::string JsonAPIAbstractRelatedResourceBuilder::identifier() const
    {
        return _identifier;
    }


}
