#include "Adapter/Database/DataSourceConfigurationFile.h"

namespace Database {


    DataSourceConfigurationFile::DataSourceConfigurationFile()
        : AbstractConfigurationFile("datasource.json")
    {}


}
