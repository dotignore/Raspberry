#include "Foundation/Http/CORSConfigurationFile.h"

namespace Foundation {
namespace Http {


    CORSConfigurationFile::CORSConfigurationFile()
        : AbstractConfigurationFile("cors.json")
    {}


} }
